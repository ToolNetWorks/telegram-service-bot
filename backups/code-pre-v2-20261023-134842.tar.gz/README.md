# ToolNet Telegram Services Bot

Telegram service storefront inspired by the layout of the example, written using only the Python 3 standard library. Includes a service catalog, quotes, wallet, manual bank transfer reconciliation, order tracking, support tickets, referrals, banner, and role-restricted administration. **This project does not generate fake platform reports, execute mass reports, or guarantee account bans.**

## VPS installation (Ubuntu, in Termius SSH)

```bash
cd /home/ubuntu
unzip telegram-service-bot.zip -d /home/ubuntu
# Folder created: /home/ubuntu/telegram-service-bot
cd /home/ubuntu/telegram-service-bot
cp .env.example .env
nano .env
chmod 600 .env
python3 bot.py
```

Create the bot with [@BotFather](https://t.me/BotFather) using `/newbot`, and put its token in `BOT_TOKEN`. Find the numeric Telegram user ID to assign Admin with a trusted ID bot or a personal `getUpdates` response. Set `ADMIN_IDS` to one or more comma-separated Telegram user IDs. If you use the service unit, the `ubuntu` Linux user must own the directory including `data/`.

You can run as root on a root-only VPS, but for a production installation use an unprivileged Linux user and restrict `.env` permissions. The bot works through Telegram long polling; no domain, webhook, nginx, or open port is required. **Run only one instance per bot token and SQLite database**. For horizontal scaling switch to webhook ingress + a server DB and distributed state.

## Install as systemd service

```bash
sudo mkdir -p /home/ubuntu/telegram-service-bot/data
sudo chown -R ubuntu:ubuntu /home/ubuntu/telegram-service-bot
sudo cp telegram-service-bot.service.example /etc/systemd/system/telegram-service-bot.service
sudo systemctl daemon-reload
sudo systemctl enable --now telegram-service-bot
sudo systemctl status telegram-service-bot --no-pager
sudo journalctl -u telegram-service-bot -n 100 --no-pager
```

Adjust the absolute paths and `User=` in the unit if you deploy somewhere else. Always take backups of `data/bot.sqlite3` with SQLite backup API or `VACUUM INTO`, not by copying a live database without its WAL files. Before exposing payments, verify your bank account data and deposit approval workflow.

## User flow

- `/start` (or Telegram Menu button) opens the home page. Admin can reply `/setbanner` to a photo or GIF to install a reusable media banner.
- User picks a service; enters link/description and evidence text, photo, video, or document. The case appears in Admin notifications.
- A service with price `0` is **quotation-only**, not free. Admin uses `/quote ORDER_ID VND`, the user then pays from wallet.
- A service with configured price > 0 is payable immediately after order submission.
- Users can deposit VND via a manual bank transfer workflow (enabled only after BANK_NAME, BANK_ACCOUNT and BANK_OWNER are set). The deposit does not credit wallet automatically: Admin must check the real bank transaction before approval.
- An order can transition `awaiting_quote → awaiting_payment → pending_review → processing → completed`, or to rejected (refund to wallet when paid).
- `/cancel` cancels an unfinished message flow, but **does not cancel an existing order**.
- `/mydeposits` shows your deposit history. `/proof ID transaction_reference` submits a pending deposit reference after reconnect; `/canceldeposit ID` cancels a deposit that still awaits proof.
- Referral deep links count signups; no automatic referral commissions.

## Admin commands

| Command | Purpose |
|---|---|
| `/admin` | Dashboard and command reference |
| `/ordersadmin` | Last 15 orders |
| `/deposits` | Pending deposits |
| `/setprice 1 500000` | Set service ID 1 price to 500,000 VND for new orders (0 means quote-only) |
| `/quote 10 500000` | Price an existing quotation request |
| `/approve 10` | Start processing a paid order |
| `/done 10` | Mark a processing order completed |
| `/reject 10` | Reject order and refund wallet if charged |
| `/approvedep 4` | Credit deposit after *independently* verifying bank receipt |
| `/rejectdep 4` | Reject deposit |
| `/credit 123456789 10000` | Manual balance adjustment (audited, Admin only) |
| `/reply 3 Hello` | Reply to support ticket 3 |
| `/setbanner` | Reply to a photo or GIF with this command |

All monetary quantities are stored as **integer VND**, never floating point. Wallet payments and deposit approvals use atomic SQLite transactions, unique ledger references and status checks to prevent double charging/crediting. Bot identity is linked to Telegram user ID, not a username.

## Security and scope

- Do not give the bot Telegram session cookies, OTPs, passwords, or another person's private content.
- No external platform-reporting automation is included. Only accept real policy violations with evidence and authorized account-recovery requests.
- No automatic transfer receipt trust: Admin must verify incoming bank payment outside Telegram.
- `/credit` can affect customer balances; keep `ADMIN_IDS` tightly controlled.
- `getUpdates` offset is persisted in SQLite. A crash between a business write and offset write may replay one update. Critical wallet transitions are idempotent; repeated case creation is keyed by request nonce. For stronger production delivery, add a dedicated events table, audit and monitoring.
- Case notes/evidence contain personal data; define retention policies and backups before public deployment.

## Run tests

```bash
python3 -m unittest discover -s tests -v
python3 -m py_compile bot.py db.py
```

## Optional extensions

Admin web dashboard; permissions per CTV/pipeline; service configuration without CLI; payment gateways with signed webhooks; invoices; Redis-backed rate limiting; role-specific auditing; image/GIF theme customizations. For high traffic, move to webhook processing and PostgreSQL.
