import os
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from bot import App


class StubTelegram:
    def __init__(self):
        self.calls = []

    def send(self, chat_id, text, markup=None):
        self.calls.append(("sendMessage", chat_id, text, markup))
        return {"message_id": len(self.calls)}

    def call(self, method, **params):
        self.calls.append((method, params))
        return True


class FlowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        fake_env = {
            "BOT_TOKEN": "100000:dummy", "ADMIN_IDS": "999", "BOT_NAME": "Test",
            "DB_PATH": os.path.join(self.tmp.name, "bot.sqlite3"), "BANK_NAME": "Demo Bank",
            "BANK_ACCOUNT": "123456789", "BANK_OWNER": "Demo Owner",
        }
        self.patch = patch.dict(os.environ, fake_env)
        self.patch.start()
        self.app = App()
        self.app.api = StubTelegram()
        self.app.username = "test_bot"

    def tearDown(self):
        self.app.db.close()
        self.patch.stop()
        self.tmp.cleanup()

    def msg(self, uid, text=None, **attrs):
        m = {"from": {"id": uid, "first_name": "Customer", "username": "user"},
             "chat": {"id": uid, "type": "private"}}
        if text is not None:
            m["text"] = text
        m.update(attrs)
        self.app.handle_message(m)

    def cb(self, uid, action):
        self.app.handle_callback({
            "id": f"q{uid}{action}", "from": {"id": uid, "first_name": "Customer"},
            "message": {"chat": {"id": uid, "type": "private"}}, "data": action,
        })

    def test_start_catalog_order_quote_pay(self):
        self.msg(111, "/start")
        self.cb(111, "service:1")
        self.cb(111, "new:1")
        self.msg(111, "https://example.com/post - report of a real violation")
        self.msg(111, "Screenshot and policy details available")
        o = self.app.db.list_orders(111)[0]
        self.assertEqual(o["status"], "awaiting_quote")
        self.msg(111, "/quote 1 200000")  # non-admin may not change anything
        self.assertEqual(self.app.db.get_order(o["id"])["status"], "awaiting_quote")
        self.msg(999, "/quote 1 200000")
        self.assertEqual(self.app.db.get_order(o["id"])["status"], "awaiting_payment")
        self.msg(999, "/credit 111 200000")
        self.cb(111, f"pay:{o['id']}")
        self.assertEqual(self.app.db.get_order(o["id"])["status"], "pending_review")
        self.msg(999, f"/approve {o['id']}")
        self.msg(999, f"/done {o['id']}")
        self.assertEqual(self.app.db.get_order(o["id"])["status"], "completed")

    def test_deposit_workflow_and_cancel(self):
        self.msg(111, "/start")
        self.cb(111, "deposit")
        self.msg(111, "50000")
        self.msg(111, photo=[{"file_id": "photo1", "width": 640, "height": 400}])
        dep = self.app.db.list_deposits()[0]
        self.msg(111, f"/approvedep {dep['id']}")  # guard
        self.assertEqual(self.app.db.get_user(111)["balance"], 0)
        self.msg(999, f"/approvedep {dep['id']}")
        self.assertEqual(self.app.db.get_user(111)["balance"], 50000)
        self.msg(999, f"/approvedep {dep['id']}")
        self.assertEqual(self.app.db.get_user(111)["balance"], 50000)


if __name__ == "__main__":
    unittest.main()
