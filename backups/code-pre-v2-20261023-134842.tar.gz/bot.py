#!/usr/bin/env python3
"""ToolNet Service Bot -- stdlib-only, long polling, manual payment verification.

Does not automate platform reports or promise removal of third-party accounts.
"""
from __future__ import annotations

import html
import json
import logging
import os
from pathlib import Path
import re
import secrets
import signal
import sys
import time
import urllib.error
import urllib.request

from db import Database

LOG = logging.getLogger("servicebot")
STATUSES = {
    "awaiting_quote": "Chờ báo giá", "awaiting_payment": "Chờ thanh toán",
    "pending_review": "Chờ xét duyệt", "processing": "Đang xử lý",
    "completed": "Hoàn thành", "rejected": "Đã từ chối/hoàn tiền",
}
MAX_TEXT = 1200


def env_file(filename=".env"):
    if not Path(filename).exists():
        return
    for line in Path(filename).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        name = name.strip()
        if re.fullmatch(r"[A-Z_][A-Z0-9_]*", name):
            os.environ.setdefault(name, value.strip().strip('"').strip("'"))


def esc(s) -> str:
    return html.escape(str(s or ""), quote=False)


def money(amount) -> str:
    return f"{int(amount):,}".replace(",", ".") + " ₫"


def keyboard(*rows):
    return {"inline_keyboard": [[{"text": title, "callback_data": data} for title, data in row]
                                for row in rows]}


HOME = keyboard(
    (("Ví tiền", "wallet"),),
    (("Gửi yêu cầu", "services"), ("Tool Access", "tools")),
    (("Hỗ trợ", "support"), ("Giới thiệu", "referral")),
    (("FAQ", "faq"), ("Cập nhật", "changelog")),
    (("Đơn của tôi", "orders"),),
)
BACK = keyboard((("← Menu chính", "home"),))


class ApiError(Exception):
    pass


class Telegram:
    def __init__(self, token: str):
        self.url = f"https://api.telegram.org/bot{token}/"

    def call(self, method: str, **params):
        request = urllib.request.Request(
            self.url + method,
            data=json.dumps(params, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                body = json.load(response)
        except (urllib.error.URLError, TimeoutError, ValueError) as exc:
            raise ApiError(f"Network/API error at {method}: {str(exc)[:200]}") from exc
        if not body.get("ok"):
            raise ApiError(f"Telegram {method}: {body.get('description', 'unknown error')}")
        return body.get("result")

    def send(self, user_id, text, markup=None):
        data = {"chat_id": user_id, "text": text, "parse_mode": "HTML",
                "disable_web_page_preview": True}
        if markup:
            data["reply_markup"] = markup
        return self.call("sendMessage", **data)


class App:
    def __init__(self):
        token = os.getenv("BOT_TOKEN", "").strip()
        if not token or ":" not in token:
            raise ValueError("BOT_TOKEN phải lấy từ @BotFather và điền vào .env")
        self.api = Telegram(token)
        self.db = Database(os.getenv("DB_PATH", "./data/bot.sqlite3"))
        self.admins = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
        if not self.admins:
            raise ValueError("ADMIN_IDS chưa thiết lập; bot yêu cầu ít nhất một Admin")
        self.name = os.getenv("BOT_NAME", "ToolNet Services")[:48]
        self.support = os.getenv("SUPPORT_USERNAME", "").lstrip("@")
        self.bank_name = os.getenv("BANK_NAME", "").strip()
        self.bank_account = os.getenv("BANK_ACCOUNT", "").strip()
        self.bank_owner = os.getenv("BANK_OWNER", "").strip()
        self.username = ""
        self.offset = int(self.db.get_setting("poll_offset") or "0")
        self.running = True

    def is_admin(self, uid):
        return uid in self.admins

    def deliver(self, uid, text, markup=None):
        try:
            self.api.send(uid, text, markup)
            return True
        except ApiError as exc:
            LOG.warning("Không gửi được tin đến %s: %s", uid, exc)
            return False

    def admins_notify(self, text, media=None):
        for uid in self.admins:
            self.deliver(uid, text)
            if media:
                kind, file_id = media
                try:
                    method = {"photo": "sendPhoto", "document": "sendDocument", "video": "sendVideo"}.get(kind)
                    if method:
                        self.api.call(method, chat_id=uid, **{kind: file_id})
                except ApiError as exc:
                    LOG.warning("Không gửi được file bằng chứng: %s", exc)

    def send_home(self, uid):
        media_kind = self.db.get_setting("banner_kind")
        media_id = self.db.get_setting("banner_id")
        if media_kind and media_id:
            method = {"photo": "sendPhoto", "animation": "sendAnimation"}.get(media_kind)
            if method:
                try:
                    self.api.call(method, chat_id=uid, **{media_kind: media_id})
                except ApiError as exc:
                    LOG.warning("Banner không gửi được: %s", exc)
        user = self.db.get_user(uid)
        greeting = esc((user["display_name"] or "bạn")[:80]) if user else "bạn"
        self.deliver(uid, f"<b>{esc(self.name)}</b>\n\nXin chào, <b>{greeting}</b>!\n"
                          "Đặt yêu cầu hỗ trợ, theo dõi tiến độ và quản lý số dư ví.\n\n"
                          "Báo cáo phải dựa trên vi phạm có thật và thông tin xác thực. "
                          "Không cam kết một tài khoản/nội dung bất kỳ sẽ bị gỡ.", HOME)

    def wallet(self, uid):
        user = self.db.get_user(uid)
        self.deliver(uid, f"<b>Ví của bạn</b>\nSố dư: <b>{money(user['balance'])}</b>\n\n"
                          "Chỉ ghi có sau khi Admin xác minh giao dịch thực tế.",
                     keyboard((("Nạp tiền", "deposit"), ("Lịch sử nạp", "mydeposits")),
                              (("← Menu chính", "home"),)))

    def services(self, uid, tool_only=False):
        rows = []
        for s in self.db.list_services():
            if tool_only and "tool" not in s["title"].lower():
                continue
            label = f"{s['title']} · {money(s['price'])}" if s["price"] else f"{s['title']} · Báo giá"
            rows.append(((label[:62], f"service:{s['id']}"),))
        rows.append((("← Menu chính", "home"),))
        self.deliver(uid, "<b>Danh mục dịch vụ</b>\nChọn dịch vụ để tạo yêu cầu.", keyboard(*rows))

    def service_detail(self, uid, service_id):
        s = self.db.get_service(service_id)
        if not s:
            return self.deliver(uid, "Dịch vụ không còn khả dụng.", BACK)
        price = money(s["price"]) if s["price"] else "Báo giá sau khi xem hồ sơ"
        self.deliver(uid, f"<b>{esc(s['title'])}</b>\n\n{esc(s['description'])}\n\n"
                          f"Chi phí: <b>{price}</b>\n"
                          "Lưu ý: không tiếp nhận yêu cầu báo cáo sai sự thật, quấy rối hoặc trả đũa.",
                     keyboard((("Tạo yêu cầu", f"new:{service_id}"),),
                              (("← Danh mục", "services"),)))

    def orders(self, uid):
        records = self.db.list_orders(uid)
        if not records:
            return self.deliver(uid, "Bạn chưa có yêu cầu nào.", BACK)
        rows = [((f"#{r['id']} · {STATUSES.get(r['status'], r['status'])}", f"order:{r['id']}"),)
                for r in records]
        rows.append((("← Menu chính", "home"),))
        self.deliver(uid, "<b>10 yêu cầu mới nhất</b>", keyboard(*rows))

    def order_detail(self, uid, oid):
        o = self.db.get_order(oid)
        if not o or (o["user_id"] != uid and not self.is_admin(uid)):
            return self.deliver(uid, "Không tìm thấy đơn hàng.")
        text = (f"<b>Yêu cầu #{o['id']}</b>\nDịch vụ: {esc(o['service_name'])}\n"
                f"Nội dung: {esc(o['subject'])}\n"
                f"Trạng thái: <b>{esc(STATUSES.get(o['status'], o['status']))}</b>\n"
                f"Chi phí: <b>{money(o['amount']) if o['amount'] else 'Chờ báo giá'}</b>")
        markup = keyboard((("Thanh toán từ ví", f"pay:{oid}"),), (("← Đơn của tôi", "orders"),)) \
            if o["status"] == "awaiting_payment" else keyboard((("← Đơn của tôi", "orders"),))
        self.deliver(uid, text, markup)

    def faq(self, uid):
        self.deliver(uid, "<b>Câu hỏi thường gặp</b>\n\n"
                     "• Đặt yêu cầu: chọn Gửi yêu cầu, mô tả đường dẫn và bằng chứng.\n"
                     "• Thanh toán: chỉ thanh toán sau khi có giá rõ ràng.\n"
                     "• Nạp ví: chuyển khoản theo mã đơn, gửi chứng từ, chờ Admin kiểm tra.\n"
                     "• Từ chối yêu cầu đã trả tiền: hoàn về ví.\n"
                     "• Dịch vụ có bảo đảm gỡ nội dung không? Không. Kết quả do nền tảng quyết định.", BACK)

    def referral(self, uid):
        link = f"https://t.me/{self.username}?start=ref_{uid}"
        self.deliver(uid, f"<b>Giới thiệu bạn bè</b>\nLink: {esc(link)}\n"
                          f"Đã giới thiệu: {self.db.referrals(uid)} người\n\n"
                          "Hiện chưa áp dụng hoa hồng tự động.", BACK)

    def bank_configured(self):
        return all([self.bank_name, self.bank_account, self.bank_owner])

    def my_deposits(self, uid):
        records = self.db.list_user_deposits(uid)
        if not records:
            return self.deliver(uid, "Chưa có yêu cầu nạp nào.", BACK)
        rows = [f"#{r['id']} · {money(r['amount'])} · {esc(r['status'])}" for r in records]
        self.deliver(uid, "<b>10 yêu cầu nạp mới nhất</b>\n" + "\n".join(rows) +
                     "\n\nNếu còn chờ chứng từ, dùng /proof MÃ_ĐƠN MÃ_GIAO_DỊCH "
                     "hoặc /canceldeposit MÃ_ĐƠN để hủy.", BACK)

    def begin_deposit(self, uid):
        if not self.bank_configured():
            return self.deliver(uid, "Chưa cấu hình thông tin nhận chuyển khoản. Hãy liên hệ hỗ trợ.", BACK)
        self.db.set_state(uid, "deposit_amount")
        self.deliver(uid, "Nhập số tiền nạp (VND), từ 10.000 đến 100.000.000.\nVí dụ: <code>200000</code>\n/cancel để hủy.")

    def begin_order(self, uid, sid):
        if not self.db.get_service(sid):
            return self.deliver(uid, "Dịch vụ không tồn tại.")
        if self.db.count_active_orders(uid) >= 5:
            return self.deliver(uid, "Bạn đang có 5 yêu cầu chưa kết thúc. Hãy xử lý các đơn cũ trước.")
        self.db.set_state(uid, "order_subject", sid=sid, nonce=secrets.token_hex(12))
        self.deliver(uid, "Nhập URL đối tượng/nội dung cần hỗ trợ và mô tả ngắn vấn đề. "
                          "Không gửi thông tin mật khẩu hoặc mã OTP.\n/cancel để hủy.")

    @staticmethod
    def proof(message):
        if message.get("photo"):
            return "photo", message["photo"][-1]["file_id"]
        if message.get("document"):
            return "document", message["document"]["file_id"]
        if message.get("video"):
            return "video", message["video"]["file_id"]
        txt = (message.get("text") or message.get("caption") or "").strip()
        return ("text", txt[:MAX_TEXT]) if txt else ("", "")

    def process_state(self, uid, message, state, data):
        value = (message.get("text") or "").strip()
        if state == "order_subject":
            if len(value) < 10 or len(value) > MAX_TEXT:
                return self.deliver(uid, "Nhập mô tả hợp lệ dài 10–1.200 ký tự.")
            self.db.set_state(uid, "order_evidence", sid=data["sid"], nonce=data["nonce"], subject=value)
            return self.deliver(uid, "Gửi bằng chứng: liên kết, mô tả chi tiết hoặc một ảnh/tệp. "
                                "Bằng chứng phải liên quan đến vi phạm thực tế.\n/cancel để hủy.")
        if state == "order_evidence":
            kind, proof = self.proof(message)
            if not proof:
                return self.deliver(uid, "Cần gửi bằng chứng dạng văn bản, ảnh, video hoặc tệp.")
            o = self.db.create_order(uid, int(data["sid"]), data["subject"], kind, proof, data["nonce"])
            self.db.set_state(uid, "")
            if not o:
                return self.deliver(uid, "Không tạo được yêu cầu. Có thể đã đạt giới hạn đơn đang chờ.", BACK)
            self.admins_notify(
                f"<b>Yêu cầu mới #{o['id']}</b>\nKhách: <code>{uid}</code>\n"
                f"Dịch vụ ID: {o['service_id']}\nMô tả: {esc(o['subject'])}\n"
                f"Bằng chứng: {esc(proof[:200]) if kind == 'text' else kind}\n"
                f"Trạng thái: {esc(o['status'])}",
                (kind, proof) if kind != "text" else None,
            )
            self.deliver(uid, f"Đã tiếp nhận yêu cầu <b>#{o['id']}</b>.")
            return self.order_detail(uid, o["id"])
        if state == "deposit_amount":
            number = re.sub(r"[.,\s]", "", value)
            if not number.isdigit() or not (10000 <= int(number) <= 100000000):
                return self.deliver(uid, "Số tiền không hợp lệ (10.000–100.000.000 VND).")
            dep = self.db.create_deposit(uid, int(number))
            if not dep:
                return self.deliver(uid, "Bạn đã có quá nhiều yêu cầu nạp đang chờ. Dùng /cancel để trở về menu.")
            self.db.set_state(uid, "deposit_proof", deposit_id=dep["id"])
            self.deliver(uid, f"<b>Thông tin chuyển khoản</b>\nNgân hàng: {esc(self.bank_name)}\n"
                             f"Chủ tài khoản: {esc(self.bank_owner)}\nSTK: <code>{esc(self.bank_account)}</code>\n"
                             f"Số tiền: <b>{money(dep['amount'])}</b>\n"
                             f"Nội dung CK: <code>TN{dep['id']}</code>\n\n"
                             "Sau khi chuyển khoản, gửi <b>ảnh chứng từ hoặc mã giao dịch</b> tại đây. "
                             "Hệ thống không tự ghi có nếu chưa được đối chiếu tại ngân hàng.")
            return
        if state == "deposit_proof":
            kind, proof = self.proof(message)
            if not proof:
                return self.deliver(uid, "Hãy gửi chứng từ hoặc mã giao dịch.")
            dep = self.db.submit_proof(int(data["deposit_id"]), uid, kind, proof)
            self.db.set_state(uid, "")
            if not dep:
                return self.deliver(uid, "Yêu cầu nạp này không còn hợp lệ. Liên hệ hỗ trợ.", BACK)
            self.deliver(uid, f"Đã nhận chứng từ nạp <b>#{dep['id']}</b>. "
                              "Ví chỉ được cộng sau khi Admin xác minh chuyển khoản thực tế.", BACK)
            return self.admins_notify(
                f"<b>Nạp ví cần xác minh #{dep['id']}</b>\nUser: <code>{uid}</code>\n"
                f"Số tiền khai báo: <b>{money(dep['amount'])}</b>\n"
                f"Chứng từ: {esc(proof[:180]) if kind == 'text' else kind}\n"
                f"Đối chiếu ngân hàng TRƯỚC khi dùng /approvedep {dep['id']}",
                (kind, proof) if kind != "text" else None,
            )
        if state == "support":
            if len(value) < 5 or len(value) > MAX_TEXT:
                return self.deliver(uid, "Nhập nội dung hỗ trợ dài 5–1.200 ký tự.")
            ticket = self.db.create_ticket(uid, value)
            self.db.set_state(uid, "")
            if not ticket:
                return self.deliver(uid, "Bạn đã gửi quá nhiều yêu cầu hỗ trợ trong 24 giờ. Vui lòng thử lại sau.")
            self.admins_notify(f"<b>Ticket #{ticket['id']}</b>\nUser: <code>{uid}</code>\n"
                               f"Nội dung: {esc(value)}\nTrả lời: /reply {ticket['id']} nội_dung")
            return self.deliver(uid, f"Đã tạo ticket <b>#{ticket['id']}</b>. Nhân viên sẽ phản hồi qua bot.", BACK)
        self.db.set_state(uid, "")
        self.send_home(uid)

    def handle_admin(self, uid, msg, cmd, arg):
        if not self.is_admin(uid):
            self.deliver(uid, "Lệnh này chỉ dành cho Admin.")
            return
        parts = arg.split(maxsplit=2)
        if cmd == "admin":
            s = self.db.stats()
            return self.deliver(uid, f"<b>Admin</b>\nUsers: {s['users']}\nOrders: {s['orders']}\n"
                                f"Nạp chờ duyệt: {s['pending_deposits']}\n\n"
                                "/ordersadmin, /deposits, /setprice ID VND, /quote ID VND, "
                                "/approve ID, /done ID, /reject ID, /approvedep ID, /rejectdep ID, "
                                "/reply ID nội_dung, /credit USER_ID VND, /setbanner (trả lời ảnh/GIF)")
        if cmd == "ordersadmin":
            records = self.db.list_orders(limit=15)
            return self.deliver(uid, "<b>15 đơn gần đây</b>\n" + "\n".join(
                f"#{r['id']} · <code>{r['user_id']}</code> · {esc(r['status'])} · {money(r['amount'])}"
                for r in records) if records else "Chưa có đơn.")
        if cmd == "deposits":
            records = self.db.list_deposits()
            return self.deliver(uid, "<b>Yêu cầu nạp chờ xác minh</b>\n" + "\n".join(
                f"#{r['id']} · <code>{r['user_id']}</code> · {money(r['amount'])}"
                for r in records) if records else "Không có yêu cầu chờ.")
        if cmd == "setbanner":
            reply = msg.get("reply_to_message") or {}
            if reply.get("animation"):
                kind, file_id = "animation", reply["animation"]["file_id"]
            elif reply.get("photo"):
                kind, file_id = "photo", reply["photo"][-1]["file_id"]
            else:
                return self.deliver(uid, "Hãy reply vào ảnh hoặc GIF bằng lệnh /setbanner.")
            self.db.set_setting("banner_kind", kind)
            self.db.set_setting("banner_id", file_id)
            return self.deliver(uid, "Đã cập nhật banner cho menu /start.")
        if cmd in ("setprice", "quote", "credit"):
            if len(parts) != 2 or not all(x.isdigit() for x in parts):
                return self.deliver(uid, f"Cú pháp: /{cmd} ID SỐ_TIỀN_VND")
            target, amount = map(int, parts)
            if cmd == "setprice":
                ok = self.db.set_price(target, amount)
                return self.deliver(uid, "Đã thay đổi giá cho các đơn mới." if ok else "Không tìm thấy dịch vụ.")
            if cmd == "credit":
                ok = self.db.credit(target, amount)
                if ok:
                    self.deliver(target, f"Admin đã ghi có <b>{money(amount)}</b> vào ví của bạn.")
                return self.deliver(uid, "Đã ghi có và lưu sổ cái." if ok else "User chưa tồn tại/số tiền không hợp lệ.")
            order = self.db.quote_order(target, amount)
            if not order:
                return self.deliver(uid, "Chỉ báo giá cho đơn đang chờ báo giá; số tiền phải > 0.")
            self.deliver(order["user_id"], f"Yêu cầu <b>#{target}</b> đã được báo giá: "
                         f"<b>{money(amount)}</b>. Mở đơn để thanh toán.",
                         keyboard((("Xem đơn / thanh toán", f"order:{target}"),)))
            return self.deliver(uid, f"Đã gửi báo giá #{target}.")
        if cmd in ("approve", "done", "reject"):
            if len(parts) != 1 or not parts[0].isdigit():
                return self.deliver(uid, f"Cú pháp: /{cmd} ORDER_ID")
            oid = int(parts[0])
            order = (self.db.reject_order(oid) if cmd == "reject" else
                     self.db.set_order_status(oid, "processing" if cmd == "approve" else "completed"))
            if not order:
                return self.deliver(uid, "Không thể chuyển trạng thái (đơn không tồn tại hoặc sai trạng thái).")
            detail = "Tiền đã hoàn về ví." if cmd == "reject" and order["paid"] else ""
            self.deliver(order["user_id"], f"Đơn <b>#{oid}</b>: "
                         f"<b>{esc(STATUSES[order['status']])}</b>. {detail}")
            return self.deliver(uid, f"Đã cập nhật #{oid}: {esc(order['status'])}.")
        if cmd in ("approvedep", "rejectdep"):
            if len(parts) != 1 or not parts[0].isdigit():
                return self.deliver(uid, f"Cú pháp: /{cmd} DEPOSIT_ID")
            dep = self.db.deposit_action(int(parts[0]), cmd == "approvedep")
            if not dep:
                return self.deliver(uid, "Đơn nạp không tồn tại, không ở trạng thái chờ hoặc đã xử lý.")
            self.deliver(dep["user_id"], f"Nạp ví <b>#{dep['id']}</b>: "
                         f"{'đã xác nhận và cộng ' + money(dep['amount']) if cmd == 'approvedep' else 'không được chấp nhận' }.")
            return self.deliver(uid, f"Đã xử lý nạp ví #{dep['id']} ({esc(dep['status'])}).")
        if cmd == "reply":
            if len(parts) < 2 or not parts[0].isdigit() or not arg.partition(" ")[2].strip():
                return self.deliver(uid, "Cú pháp: /reply TICKET_ID nội dung trả lời")
            ticket = self.db.ticket(int(parts[0]))
            if not ticket:
                return self.deliver(uid, "Ticket không tồn tại.")
            body = arg.partition(" ")[2].strip()[:MAX_TEXT]
            delivered = self.deliver(ticket["user_id"],
                                     f"<b>Phản hồi ticket #{ticket['id']}</b>\n{esc(body)}", BACK)
            return self.deliver(uid, "Đã gửi phản hồi." if delivered else "Không gửi được phản hồi.")
        self.deliver(uid, "Lệnh Admin không được hỗ trợ.")

    def handle_message(self, msg):
        person = msg.get("from") or {}
        uid = person.get("id")
        if not uid or msg.get("chat", {}).get("type") != "private":
            return
        text = (msg.get("text") or "").strip()
        match = re.match(r"^/(\w+)(?:@\w+)?(?:\s+([\s\S]*))?$", text)
        cmd, arg = (match.group(1).lower(), (match.group(2) or "").strip()) if match else ("", "")
        referral = None
        if cmd == "start" and re.fullmatch(r"ref_\d{1,16}", arg):
            referral = int(arg[4:])
        self.db.ensure_user(uid, person.get("username") or "", person.get("first_name") or "", referral)
        if cmd in ("start", "menu", "cancel"):
            self.db.set_state(uid, "")
            return self.send_home(uid)
        if cmd in ("admin", "ordersadmin", "deposits", "setprice", "quote", "credit",
                   "approve", "done", "reject", "approvedep", "rejectdep", "reply", "setbanner"):
            return self.handle_admin(uid, msg, cmd, arg)
        if cmd == "canceldeposit":
            if not arg.isdigit():
                return self.deliver(uid, "Cú pháp: /canceldeposit DEPOSIT_ID")
            ok = self.db.cancel_deposit(int(arg), uid)
            self.db.set_state(uid, "")
            return self.deliver(uid, "Đã hủy đơn nạp chưa gửi chứng từ." if ok else
                                "Không thể hủy: đơn không thuộc về bạn hoặc đã chuyển sang xét duyệt.", BACK)
        if cmd == "proof":
            parts = arg.split(maxsplit=1)
            if len(parts) != 2 or not parts[0].isdigit():
                return self.deliver(uid, "Cú pháp: /proof DEPOSIT_ID mã_giao_dịch")
            dep = self.db.submit_proof(int(parts[0]), uid, "text", parts[1][:MAX_TEXT])
            if not dep:
                return self.deliver(uid, "Không tìm thấy khoản nạp đang chờ chứng từ.")
            self.db.set_state(uid, "")
            self.admins_notify(f"Nạp ví #{dep['id']} cần xác minh · User {uid} · "
                               f"{money(dep['amount'])} · Chứng từ {esc(parts[1][:200])}")
            return self.deliver(uid, "Đã gửi chứng từ; chờ Admin kiểm tra ngân hàng.")
        state, data = self.db.get_state(uid)
        if state:
            return self.process_state(uid, msg, state, data)
        if cmd == "wallet":
            return self.wallet(uid)
        if cmd == "mydeposits":
            return self.my_deposits(uid)
        if cmd == "services":
            return self.services(uid)
        if cmd == "orders":
            return self.orders(uid)
        if cmd == "help":
            return self.faq(uid)
        self.deliver(uid, "Chọn một chức năng từ menu hoặc dùng /menu.", HOME)

    def handle_callback(self, query):
        person = query.get("from") or {}
        uid = person.get("id")
        if not uid:
            return
        try:
            self.api.call("answerCallbackQuery", callback_query_id=query["id"])
        except ApiError as exc:
            LOG.info("Không ACK callback: %s", exc)
        # Require a private chat, not a forwarded/shared inline message.
        if (query.get("message") or {}).get("chat", {}).get("type") != "private":
            return
        self.db.ensure_user(uid, person.get("username") or "", person.get("first_name") or "")
        action = query.get("data", "")
        if action == "home":
            self.db.set_state(uid, "")
            return self.send_home(uid)
        if action == "wallet":
            return self.wallet(uid)
        if action == "mydeposits":
            return self.my_deposits(uid)
        if action == "services":
            return self.services(uid)
        if action == "tools":
            return self.services(uid, tool_only=True)
        if action == "orders":
            return self.orders(uid)
        if action == "deposit":
            return self.begin_deposit(uid)
        if action == "support":
            self.db.set_state(uid, "support")
            return self.deliver(uid, "Nhập nội dung cần hỗ trợ (5–1.200 ký tự). /cancel để hủy.")
        if action == "referral":
            return self.referral(uid)
        if action == "faq":
            return self.faq(uid)
        if action == "changelog":
            return self.deliver(uid, "<b>Changelog v1.0</b>\n• Danh mục dịch vụ\n"
                                "• Đơn hàng và trạng thái\n• Ví VND\n• Hỗ trợ và giới thiệu", BACK)
        if re.fullmatch(r"service:\d+", action):
            return self.service_detail(uid, int(action.split(":")[1]))
        if re.fullmatch(r"new:\d+", action):
            return self.begin_order(uid, int(action.split(":")[1]))
        if re.fullmatch(r"order:\d+", action):
            return self.order_detail(uid, int(action.split(":")[1]))
        if re.fullmatch(r"pay:\d+", action):
            oid = int(action.split(":")[1])
            outcome = self.db.pay_order(oid, uid)
            if outcome == "paid":
                self.admins_notify(f"<b>Đơn #{oid} đã thanh toán từ ví</b>.\nKiểm tra hồ sơ và /approve {oid} hoặc /reject {oid}.")
                return self.deliver(uid, f"Đã thanh toán đơn <b>#{oid}</b>. Chờ Admin xét duyệt.", BACK)
            messages = {"insufficient": "Số dư ví không đủ. Hãy nạp tiền và thanh toán lại.",
                        "already_paid": "Đơn này đã thanh toán.",
                        "not_payable": "Đơn hiện không thể thanh toán.",
                        "missing": "Bạn không có quyền truy cập đơn này."}
            return self.deliver(uid, messages.get(outcome, "Lỗi thanh toán."), BACK)
        self.deliver(uid, "Thao tác không hợp lệ, quay lại /menu.")

    def serve(self):
        me = self.api.call("getMe")
        self.username = me["username"]
        self.api.call("deleteWebhook", drop_pending_updates=False)
        self.api.call("setMyCommands", commands=[
            {"command": "start", "description": "Mở menu chính"},
            {"command": "wallet", "description": "Kiểm tra ví"},
            {"command": "services", "description": "Danh mục dịch vụ"},
            {"command": "orders", "description": "Đơn của tôi"},
            {"command": "help", "description": "Hướng dẫn"},
            {"command": "cancel", "description": "Hủy thao tác"},
        ])
        LOG.info("Bot @%s đã hoạt động, admin count=%s", self.username, len(self.admins))
        retry = 1
        while self.running:
            try:
                updates = self.api.call("getUpdates", offset=self.offset, timeout=25,
                                        limit=50, allowed_updates=["message", "callback_query"])
                retry = 1
                for update in updates:
                    # Move offset even on handler failure so one poisoned update doesn't block all traffic.
                    self.offset = max(self.offset, update["update_id"] + 1)
                    try:
                        if "message" in update:
                            self.handle_message(update["message"])
                        elif "callback_query" in update:
                            self.handle_callback(update["callback_query"])
                    except Exception:
                        LOG.exception("Lỗi xử lý update_id=%s", update["update_id"])
                    finally:
                        self.db.set_setting("poll_offset", str(self.offset))
            except (ApiError, OSError):
                LOG.exception("Lỗi polling; sẽ thử lại")
                time.sleep(min(retry, 30))
                retry *= 2

    def stop(self, *_):
        self.running = False


def main():
    env_file()
    logging.basicConfig(level=getattr(logging, os.getenv("LOG_LEVEL", "INFO").upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    app = App()
    signal.signal(signal.SIGTERM, app.stop)
    signal.signal(signal.SIGINT, app.stop)
    try:
        app.serve()
    finally:
        app.db.close()


if __name__ == "__main__":
    main()
