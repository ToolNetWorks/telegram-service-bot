import os
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from bot import App, TOOLS_GIF, WELCOME_GIF


class StubTelegram:
    def __init__(self):
        self.calls = []

    def send(self, chat_id, text, markup=None):
        self.calls.append(("sendMessage", chat_id, text, markup))
        return {"message_id": len(self.calls)}

    def call(self, method, **params):
        self.calls.append((method, params))
        return True

    def send_media(self, chat_id, kind, file_id, caption, markup=None):
        method = {"photo": "sendPhoto", "animation": "sendAnimation"}[kind]
        return self.call(method, **{"chat_id": chat_id, kind: file_id,
                                    "caption": caption, "reply_markup": markup})

    def send_animation_file(self, chat_id, path, caption, markup=None):
        name = os.path.splitext(os.path.basename(path))[0]
        self.calls.append(("sendAnimationFile", chat_id, caption, markup))
        return {"animation": {"file_id": f"{name}-file-id"}}


class FlowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        fake_env = {
            "BOT_TOKEN": "100000:dummy", "ADMIN_IDS": "999", "BOT_NAME": "Test",
            "DB_PATH": os.path.join(self.tmp.name, "bot.sqlite3"), "BANK_NAME": "Demo Bank",
            "BANK_ACCOUNT": "123456789", "BANK_OWNER": "Demo Owner",
        }
        self.patch = patch.dict(os.environ, fake_env)
        self.patch.start()
        self.app = App()
        self.app.api = StubTelegram()
        self.app.username = "test_bot"

    def tearDown(self):
        self.app.db.close()
        self.patch.stop()
        self.tmp.cleanup()

    def msg(self, uid, text=None, **attrs):
        m = {"from": {"id": uid, "first_name": "Customer", "username": "user"},
             "chat": {"id": uid, "type": "private"}}
        if text is not None:
            m["text"] = text
        m.update(attrs)
        self.app.handle_message(m)

    def cb(self, uid, action):
        self.app.handle_callback({
            "id": f"q{uid}{action}", "from": {"id": uid, "first_name": "Customer"},
            "message": {"chat": {"id": uid, "type": "private"}}, "data": action,
        })

    def onboard(self, uid=111, language="vi"):
        self.msg(uid, "/start")
        state, data = self.app.db.get_state(uid)
        self.assertEqual(state, "captcha")
        self.msg(uid, str(data["a"] + data["b"]))
        self.assertTrue(self.app.db.get_user(uid)["verified_at"])
        self.cb(uid, f"lang:{language}")
        self.assertEqual(self.app.db.get_user(uid)["language"], language)

    def last_markup(self):
        for call in reversed(self.app.api.calls):
            if len(call) >= 4 and call[0] in ("sendMessage", "sendAnimationFile") and call[3]:
                return call[3]
            if call[0] in ("sendAnimation", "sendPhoto") and len(call) >= 2 and isinstance(call[1], dict):
                markup = call[1].get("reply_markup")
                if markup:
                    return markup
        raise AssertionError("no message with inline keyboard")

    def buttons(self):
        return [button["callback_data"]
                for row in self.last_markup()["inline_keyboard"] for button in row]

    def test_main_menu_excludes_report_and_tool_access_has_submenu(self):
        self.onboard()
        self.msg(111, "/start")
        self.assertNotIn("services", self.buttons())
        self.assertIn("tools", self.buttons())

        self.cb(111, "tools")
        self.assertEqual(self.buttons(), ["tools:report", "tools:buy", "tools:sub", "home"])

        self.cb(111, "tools:report")
        self.assertIn("platform:telegram", self.buttons())
        self.assertEqual(self.buttons()[-1], "tools")

        self.cb(111, "home")
        self.cb(111, "tools")
        self.cb(111, "tools:buy")
        tool_ids = [f"service:{s['id']}" for s in self.app.db.list_services("tools")]
        self.assertEqual(self.buttons(), tool_ids + ["tools"])

        self.cb(111, "tools:sub")
        self.assertIn("chưa có gói Tool Access", self.app.api.calls[-1][2])
        self.assertEqual(self.buttons(), ["tools:buy", "tools"])

    def test_tool_access_back_navigation(self):
        self.onboard()
        self.app.api.calls.clear()
        self.cb(111, "tools")
        self.assertEqual(self.buttons(), ["tools:report", "tools:buy", "tools:sub", "home"])

        self.app.api.calls.clear()
        self.cb(111, "tools:report")
        self.assertIn("platform:telegram", self.buttons())
        self.assertEqual(self.buttons()[-1], "tools")

        self.app.api.calls.clear()
        self.cb(111, "platform:tiktok")
        self.assertIn("services", self.buttons())

        self.app.api.calls.clear()
        self.cb(111, "service:1")
        self.assertIn("platform:tiktok", self.buttons())

        self.app.api.calls.clear()
        self.cb(111, "platform:tiktok")
        self.assertIn("services", self.buttons())

        self.app.api.calls.clear()
        self.cb(111, "services")
        self.assertEqual(self.buttons()[-1], "tools")

        self.app.api.calls.clear()
        self.cb(111, "tools")
        self.assertEqual(self.buttons(), ["tools:report", "tools:buy", "tools:sub", "home"])

        self.app.api.calls.clear()
        self.cb(111, "tools:buy")
        tool_id = self.app.db.list_services("tools")[0]["id"]
        self.app.api.calls.clear()
        self.cb(111, f"service:{tool_id}")
        self.assertIn("tools:buy", self.buttons())

        self.app.api.calls.clear()
        self.cb(111, "tools:buy")
        self.assertEqual(self.buttons()[-1], "tools")

    def test_welcome_gif_on_start_after_onboarding(self):
        if not WELCOME_GIF.is_file():
            self.skipTest("assets/gifs/welcome.gif is missing")
        self.onboard()
        uploads = [c for c in self.app.api.calls if c[0] == "sendAnimationFile"]
        self.assertEqual(len(uploads), 1)
        self.assertIn("Chào mừng", uploads[0][2])
        self.assertEqual(self.app.db.get_setting("welcome_gif_id"), "welcome-file-id")
        self.assertTrue(self.app.db.get_setting("welcome_gif_sig"))

        self.app.api.calls.clear()
        self.msg(111, "/start")
        cached = [c for c in self.app.api.calls if c[0] == "sendAnimation"]
        self.assertEqual(len(cached), 1)
        self.assertEqual(cached[0][1]["animation"], "welcome-file-id")

        self.app.api.calls.clear()
        self.msg(111, "/menu")
        self.assertFalse(any(c[0] in ("sendAnimation", "sendAnimationFile")
                             for c in self.app.api.calls))

    def test_tool_access_menu_sends_image(self):
        if not TOOLS_GIF.is_file():
            self.skipTest("assets/gifs/tools.gif is missing")
        self.onboard()
        self.app.api.calls.clear()
        self.cb(111, "tools")
        uploads = [c for c in self.app.api.calls if c[0] == "sendAnimationFile"]
        self.assertEqual(len(uploads), 1)
        self.assertIn("Tool Access", uploads[0][2])
        self.assertEqual(self.app.db.get_setting("tools_gif_id"), "tools-file-id")

        self.app.api.calls.clear()
        self.cb(111, "tools")
        self.assertFalse(any(c[0] == "sendAnimationFile" for c in self.app.api.calls))
        cached = [c for c in self.app.api.calls if c[0] == "sendAnimation"]
        self.assertEqual(len(cached), 1)
        self.assertEqual(cached[0][1]["animation"], "tools-file-id")
        self.assertEqual(self.buttons(), ["tools:report", "tools:buy", "tools:sub", "home"])

        self.app.api.calls.clear()
        self.msg(111, "/start")
        self.assertFalse(any(c[0] == "sendAnimationFile" for c in self.app.api.calls))
        welcome = [c for c in self.app.api.calls if c[0] == "sendAnimation"]
        self.assertEqual(len(welcome), 1)
        self.assertEqual(welcome[0][1]["animation"], "welcome-file-id")

    def test_start_catalog_order_quote_pay(self):
        self.onboard()
        self.cb(111, "tools")
        self.cb(111, "tools:report")
        self.cb(111, "platform:tiktok")
        self.cb(111, "service:1")
        self.cb(111, "new:1")
        self.cb(111, "target:1:post")
        self.msg(111, "https://www.tiktok.com/@creator/video/1234567890")
        self.msg(111, "The content impersonates a real business and shows deceptive contact information.")
        self.msg(111, "Screenshot and policy details available")
        o = self.app.db.list_orders(111)[0]
        self.assertEqual(o["status"], "awaiting_quote")
        self.msg(111, "/quote 1 200000")  # non-admin may not change anything
        self.assertEqual(self.app.db.get_order(o["id"])["status"], "awaiting_quote")
        self.msg(999, "/quote 1 200000")
        self.assertEqual(self.app.db.get_order(o["id"])["status"], "awaiting_payment")
        self.msg(999, "/credit 111 200000")
        self.cb(111, f"pay:{o['id']}")
        self.assertEqual(self.app.db.get_order(o["id"])["status"], "pending_review")
        self.msg(999, f"/approve {o['id']}")
        self.msg(999, f"/done {o['id']}")
        self.assertEqual(self.app.db.get_order(o["id"])["status"], "completed")

    def test_deposit_workflow_and_cancel(self):
        self.onboard()
        self.cb(111, "deposit")
        self.msg(111, "50000")
        self.msg(111, photo=[{"file_id": "photo1", "width": 640, "height": 400}])
        dep = self.app.db.list_deposits()[0]
        self.msg(111, f"/approvedep {dep['id']}")  # guard
        self.assertEqual(self.app.db.get_user(111)["balance"], 0)
        self.msg(999, f"/approvedep {dep['id']}")
        self.assertEqual(self.app.db.get_user(111)["balance"], 50000)
        self.msg(999, f"/approvedep {dep['id']}")
        self.assertEqual(self.app.db.get_user(111)["balance"], 50000)

    def test_verification_rejects_wrong_answers_and_cannot_skip(self):
        self.msg(111, "/start")
        self.cb(111, "wallet")
        self.assertFalse(self.app.db.get_user(111)["verified_at"])
        self.msg(111, "-999")
        state, data = self.app.db.get_state(111)
        self.assertEqual(state, "captcha")
        self.assertEqual(data["tries"], 1)
        self.msg(111, "-999")
        self.msg(111, "-999")
        state, data = self.app.db.get_state(111)
        self.assertEqual(state, "captcha")
        self.assertEqual(data["tries"], 0)
        self.msg(111, str(data["a"] + data["b"]))
        self.assertTrue(self.app.db.get_user(111)["verified_at"])
        self.cb(111, "lang:en")
        self.assertEqual(self.app.db.get_user(111)["language"], "en")
        self.cb(111, "language")
        self.cb(111, "lang:vi")
        self.assertEqual(self.app.db.get_user(111)["language"], "vi")

    def test_invalid_targets_and_media_greeting(self):
        self.onboard(language="en")
        self.cb(111, "target:5:channel")
        state, _ = self.app.db.get_state(111)
        self.assertEqual(state, "order_target")
        self.msg(111, "https://evil.example/watch?v=12")
        state, _ = self.app.db.get_state(111)
        self.assertEqual(state, "order_target")
        self.msg(111, "https://www.youtube.com/@examplechannel")
        state, _ = self.app.db.get_state(111)
        self.assertEqual(state, "order_reason")
        self.msg(999, "/setbanner", reply_to_message={"animation": {"file_id": "gif-id"}})
        self.msg(111, "/start")
        calls = [c for c in self.app.api.calls if c[0] == "sendAnimation"]
        self.assertTrue(calls)
        self.assertEqual(calls[-1][1]["animation"], "gif-id")
        self.assertIn("reply_markup", calls[-1][1])

    def test_no_bypass_before_language_selection(self):
        self.msg(111, "/start")
        state, data = self.app.db.get_state(111)
        self.msg(111, str(data["a"] + data["b"]))
        self.cb(111, "services")
        self.assertEqual(self.app.db.list_orders(111), [])
        self.cb(111, "lang:en")
        self.cb(111, "services")
        self.assertTrue(any("choose" in c[2].lower() or "platform" in c[2].lower()
                            for c in self.app.api.calls if c[0] == "sendMessage"))


if __name__ == "__main__":
    unittest.main()
