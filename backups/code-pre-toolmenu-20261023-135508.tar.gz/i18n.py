"""Offline UI translations. English fallback for specialist messages/admin workflows.

Languages are selected by the user (never guessed from their Telegram profile).
"""

LANGUAGES = {"vi": "Tiếng Việt", "en": "English"}

EN = {
    "wallet": "Wallet", "report": "Send Report", "tools": "Tool Access",
    "support": "Support", "referral": "Referral", "faq": "FAQ",
    "changes": "Changelogs", "orders": "My Orders", "back": "← Main Menu",
    "back_platforms": "← Back to Platforms", "language": "Language",
    "choose_language": "Verified!\n\nWelcome to our community!\nChoose your language below to get started.",
    "choose_platform": "Select the platform for your policy-compliance request.",
    "choose_service": "Select a service to open a case.",
    "choose_target": "Choose the target type:",
    "profile": "Profile", "channel": "Channel", "group": "Group",
    "post": "Post / Video", "send_target": "Send the profile/channel/post URL, @username or public ID in your next message.\n/cancel to exit.",
    "describe": "Explain the specific policy violation and why it should be reviewed (10–1,200 characters).\n/cancel to exit.",
    "evidence": "Send supporting evidence as text, a screenshot, a file or a video.\n/cancel to exit.",
    "captcha": "🔐 Verification Required\n\nSolve this math problem to continue:\n\n{a} + {b} = ?\n\nType your answer below.",
    "captcha_bad": "Incorrect answer. Attempts remaining: {remaining}.",
    "captcha_expired": "Verification expired. Here is a new question.",
    "verified": "Verified!",
    "home": "Welcome back, <b>{name}</b>!\n\nChoose a service, manage your wallet or contact support.\n\nOnly genuine policy violations with evidence can be submitted. Platform decisions are not guaranteed.",
    "invalid_target": "Enter a valid public profile URL, @username or ID (up to 500 characters).",
    "invalid_reason": "Provide a clear explanation (10–1,200 characters).",
    "invalid_evidence": "Supporting evidence is required as text, photo, file or video.",
    "submitted": "Your case <b>#{order_id}</b> has been received for manual review.",
    "no_services": "No services are available for this platform.",
    "price_quote": "Price available after review",
    "create": "Create case", "description": "Service Details", "cost": "Price",
}

VI = {
    "wallet": "Ví tiền", "report": "Gửi báo cáo", "tools": "Tool Access",
    "support": "Hỗ trợ", "referral": "Giới thiệu", "faq": "FAQ",
    "changes": "Cập nhật", "orders": "Đơn của tôi", "back": "← Menu chính",
    "back_platforms": "← Nền tảng", "language": "Ngôn ngữ",
    "choose_language": "Đã xác minh!\n\nChào mừng đến cộng đồng.\nChọn ngôn ngữ để bắt đầu.",
    "choose_platform": "Chọn nền tảng có nội dung cần rà soát vi phạm.",
    "choose_service": "Chọn dịch vụ để tạo hồ sơ.",
    "choose_target": "Chọn loại đối tượng:",
    "profile": "Trang cá nhân", "channel": "Kênh", "group": "Nhóm",
    "post": "Bài đăng / Video", "send_target": "Gửi URL công khai, @username hoặc ID cần rà soát ở tin nhắn tiếp theo.\n/cancel để hủy.",
    "describe": "Mô tả vi phạm cụ thể và căn cứ chính sách (10–1.200 ký tự).\n/cancel để hủy.",
    "evidence": "Gửi bằng chứng dạng văn bản, ảnh chụp, tệp hoặc video.\n/cancel để hủy.",
    "captcha": "🔐 Yêu cầu xác minh\n\nGiải phép tính để tiếp tục:\n\n{a} + {b} = ?\n\nNhập câu trả lời bên dưới.",
    "captcha_bad": "Chưa đúng. Còn {remaining} lần thử.",
    "captcha_expired": "Mã xác minh hết hạn. Đây là câu hỏi mới.",
    "verified": "Xác minh thành công!",
    "home": "Chào mừng trở lại, <b>{name}</b>!\n\nChọn dịch vụ, quản lý ví tiền hoặc liên hệ hỗ trợ.\n\nChỉ tiếp nhận báo cáo vi phạm có thật và có bằng chứng. Không cam kết quyết định của nền tảng.",
    "invalid_target": "Nhập URL công khai, @username hoặc ID hợp lệ (tối đa 500 ký tự).",
    "invalid_reason": "Hãy mô tả rõ vi phạm (10–1.200 ký tự).",
    "invalid_evidence": "Cần gửi bằng chứng dưới dạng chữ, ảnh, tệp hoặc video.",
    "submitted": "Đã nhận hồ sơ <b>#{order_id}</b> để quản trị viên xét duyệt.",
    "no_services": "Nền tảng này chưa có dịch vụ.",
    "price_quote": "Báo giá sau khi thẩm định",
    "create": "Tạo hồ sơ", "description": "Chi tiết dịch vụ", "cost": "Chi phí",
}



def translate(language: str, key: str, **params) -> str:
    template = VI.get(key, EN.get(key, key)) if language == "vi" else EN.get(key, key)
    return template.format(**params)
